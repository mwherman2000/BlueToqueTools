﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N4KSyntheticPressureCurve
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int p, d1, d2, d3, d4, d5;
            int m, t0, t1, t2, t3, t4, t5;
            p = 10;
            d1 = 5;
            d2 = 10;
            d3 = 30;
            d4 = 10;
            d5 = 5;

            char ch = '-';
            while (ch != 'q')
            {
                switch(ch)
                {  
                    case 'a': { d1++; if (d1 > 10) { d1 = 10; Console.Beep(); } break; }
                    case 'A': { d1--; if (d1 < 1) { d1 = 1;   Console.Beep(); } break; }
                    case 'p': { d2++; if (d2 > 30) { d2 = 30; Console.Beep(); } break; }
                    case 'P': { d2--; if (d2 < 1) { d2 = 1;   Console.Beep(); } break; }
                    case 's': { d3++; if (d3 > 30) { d3 = 30; Console.Beep(); } break; }
                    case 'S': { d3--; if (d3 < 1) { d3 = 1;   Console.Beep(); } break; }
                    case 'r': { d4++; if (d4 > 30) { d4 = 30; Console.Beep(); } break; }
                    case 'R': { d4--; if (d4 < 1) { d4 = 1;   Console.Beep(); } break; }
                    default: { break; }

                }

                t0 = 0;
                t1 = t0 + d1;
                t2 = t1 + d2;
                t3 = t2 + d3;
                t4 = t3 + d4;

                d5 = (d2 + d3 + d4) / 5;
                t5 = t4 + d5;

                p = 11 - d1;
                m = t3 - (d3 / 2);

                Console.Clear();
                Console.WriteLine("BlueToqueTools N4K Synthentic Pressure Curve for a Kiss version 0.1");
                Console.WriteLine("Time unit: 0.1 second");
                Console.WriteLine();
                Console.WriteLine("t0=" + t0.ToString() + "\tAPPROACH (approach " + d1.ToString() + ")");
                Console.WriteLine("t1=" + t1.ToString() + "\tPRESS    (press    " + d2.ToString() + ")");
                Console.WriteLine("t2=" + t2.ToString() + "\tSUSTAIN  (sustain  " + d3.ToString() + ")");
                Console.WriteLine("t3=" + t3.ToString() + "\tRELEASE  (release  " + d4.ToString() + ")");
                Console.WriteLine("t4=" + t4.ToString() + "\tRECOVERY (recovery " + d5.ToString() + ")");
                Console.WriteLine("t5=" + t5.ToString() + "\tFINISH");
                Console.WriteLine();
                Console.WriteLine("m=" + m.ToString()   + "\tMEDIAN   |");
                Console.WriteLine("p=" + p.ToString()   + "\tPEAK     *");

                //Console.WriteLine();
                int[] left = GetScaledLeftCurve(p, d2);
                int[] right = GetScaledRightCurve(p, d4);

                // Draw timeline
                Console.WriteLine();
                Console.Write(">");
                for (int t = 1; t <= d1; t++) Console.Write("a");
                for (int t = 1; t <= d2; t++) Console.Write("p");
                for (int t = 1; t <= d3; t++) Console.Write("s");
                for (int t = 1; t <= d4; t++) Console.Write("r");
                for (int t = 1; t <= d5; t++) Console.Write("v");
                Console.WriteLine();

                // Clear chart
                char[][] chart = new char[10][];
                for (int i = 0; i < chart.Length; i++) chart[i] = new char[150];
                foreach (var row in chart)
                {
                    for (int i = 0; i < row.Length; i++) row[i] = '.'; // Background
                }

                // Draw synthetic pressure curve
                for (int i = t0+1; i <= t1; i++) chart[1 - 1][i - 1] = '_'; // APPROACH

                for (int i = 1; i <= d2; i++)
                {
                    int y = left[i - 1];
                    chart[y - 1][t1 + i - 1] = '/'; // PRESS
                }

                for (int t = t2+1; t <= t3; t++) chart[p - 1][t - 1] = '='; // SUSTAIN

                foreach (var row in chart)
                {
                    row[m - 1] = '|'; // PEAK
                }
                chart[p-1][m-1] = '*';  // TOP

                for (int i = 1; i <= d4; i++)
                {
                    int y = right[i - 1];
                    chart[y - 1][t3 + i - 1] = '\\'; // RELEASE
                }

                for (int t = t4 + 1; t <= t5; t++) chart[1 - 1][t - 1] = '_'; // RECOVERY

                // Output synthetic pressure curve
                Console.WriteLine();
                for (int y = 10; y > 0; y--)
                {
                    Console.Write((y % 10).ToString());
                    for (int x = 0; x < t5; x++) Console.Write(chart[y-1][x]);
                    Console.WriteLine();
                }
                for (int x = 0; x <= t5; x++)
                {
                    if ((x % 10) == 0)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write((x % 10).ToString());
                    }
                }
                Console.WriteLine();

                // Calculate and output DID Identifiers
                string didNfe = "did:bluetoquenfe:" + Guid.NewGuid().ToString();
                string didDeed = "did:bluetoquedeed:" + Guid.NewGuid().ToString();
                string didObject = "did:object:" + Guid.NewGuid().ToString();
                Console.WriteLine();
                Console.WriteLine("DID Identifiers (associated with this curve (kiss)):");
                Console.WriteLine(didObject);
                Console.WriteLine(didDeed);
                Console.WriteLine("-> " + didNfe);

                ch = Console.ReadKey(true).KeyChar;
            }

            Console.WriteLine();
            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine(); 
        }

        static int[] GetScaledLeftCurve(int peak, int duration)
        {
            const double PI = 3.14159;

            int[] result = new int[duration];

            //Console.WriteLine("peak, duration: " + peak.ToString() + " " + duration.ToString());

            double a = 0; 
            for (int i = 0; i < duration; i++)
            {
                double y = System.Math.Sin(a);
                int iy = (int)System.Math.Round(y * (peak-1)) + 1;
                result[i] = iy;
                //Console.WriteLine(i.ToString() + "\t" + a.ToString() + "\t" + y.ToString() + "\t" + result[i].ToString());
                a += (PI / 2) / duration;
            }

            return result; 
        }

        static int[] GetScaledRightCurve(int peak, int duration)
        {
            //Console.WriteLine("peak, duration: " + peak.ToString() + " " + duration.ToString());

            int[] result = GetScaledLeftCurve(peak, duration);

            for (int i = 0; i < duration/2; i++)
            {
                int temp = result[i]; 
                result[i] = result[duration - 1 - i];
                result[duration - 1 - i] = temp;
            }

            //for (int i = 0; i < duration; i++)
            //{
            //    Console.WriteLine(i.ToString() + "\t" + result[i].ToString());
            //}

            return result;
        }
    }
}
